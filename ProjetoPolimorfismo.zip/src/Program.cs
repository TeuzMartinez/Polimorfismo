
using System;
using System.Collections.Generic;

namespace ProjetoPolimorfismo
{
    abstract class Documento
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public DateTime DataCriacao { get; set; }

        public virtual void Imprimir()
        {
            Console.WriteLine($"Titulo: {Titulo}, Autor: {Autor}, Data: {DataCriacao}");
        }

        public virtual string ConteudoFormatado()
        {
            return $"Documento: {Titulo} - {Autor}";
        }
    }

    class DocumentoTexto : Documento
    {
        public override void Imprimir()
        {
            Console.WriteLine("Documento de Texto:");
            base.Imprimir();
        }

        public override string ConteudoFormatado()
        {
            return $"[Texto] {Titulo} por {Autor}";
        }

        public int ContarPalavras(string conteudo)
        {
            return conteudo.Split(' ').Length;
        }
    }

    class ProcessadorDocumentos
    {
        public void ProcessarLote(List<Documento> documentos)
        {
            foreach (var doc in documentos)
            {
                doc.Imprimir();
                Console.WriteLine(doc.ConteudoFormatado());
                Console.WriteLine();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var doc1 = new DocumentoTexto { Titulo = "Teste", Autor = "Aluno", DataCriacao = DateTime.Now };
            var documentos = new List<Documento> { doc1 };
            var processador = new ProcessadorDocumentos();
            processador.ProcessarLote(documentos);
        }
    }
}
